https://travis-ci.org/danieltran67/All-In-One-Agenda.svg?branch=master
